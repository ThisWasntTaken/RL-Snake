import torch
import numpy as np

from torch.nn import Conv2d, Linear, Module
from gym.wrappers import FrameStack

from agents import Q_Agent, Vanilla_DQN_Agent, Double_DQN_Priority_Agent
from utils import linear_decay_schedule, linear_growth_schedule
from snake import Snake, Position


class SnakeSimpleModel(Module):
    def __init__(self):
        super(SnakeSimpleModel, self).__init__()
        self.fc1 = Linear(16, 32)
        self.fc2 = Linear(32, 16)
        self.fc3 = Linear(16, 4)
        torch.nn.init.kaiming_uniform_(self.fc1.weight)
        torch.nn.init.kaiming_uniform_(self.fc2.weight)
        torch.nn.init.kaiming_uniform_(self.fc3.weight)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x


class SnakeSimple(Snake):

    def __init__(self, num_columns, num_rows, low=0, high=1, state_shape=(16,), seed=None):
        super().__init__(
            num_columns = num_columns,
            num_rows = num_rows,
            low = low,
            high = high,
            state_shape = state_shape,
            seed = seed
            )
    
    def _blocked(self, x, y):
        return not ((0 <= x < self.num_columns and 0 <= y < self.num_rows) and (Position(x, y) not in self.body))
    
    @property
    def state(self):
        return (
            int(self._blocked(self.head.x + 1, self.head.y)),
            int(self._blocked(self.head.x - 1, self.head.y)),
            int(self._blocked(self.head.x, self.head.y + 1)),
            int(self._blocked(self.head.x, self.head.y - 1)),
            int(self._blocked(self.head.x + 1, self.head.y + 1)),
            int(self._blocked(self.head.x + 1, self.head.y - 1)),
            int(self._blocked(self.head.x - 1, self.head.y + 1)),
            int(self._blocked(self.head.x - 1, self.head.y - 1)),
            int(self.apple.x > self.head.x and self.apple.y == self.head.y),
            int(self.apple.y > self.head.y and self.apple.x == self.head.x),
            int(self.apple.x < self.head.x and self.apple.y == self.head.y),
            int(self.apple.y < self.head.y and self.apple.x == self.head.x),
            int(self.apple.x > self.head.x and self.apple.y > self.head.y),
            int(self.apple.x > self.head.x and self.apple.y < self.head.y),
            int(self.apple.x < self.head.x and self.apple.y > self.head.y),
            int(self.apple.x < self.head.x and self.apple.y < self.head.y),
            )
    
    def _crash(self):
        if self.head.x > self.num_columns - 1 or self.head.x < 0 or\
            self.head.y > self.num_rows - 1 or self.head.y < 0 or\
            self.head in self.body[1:]:
            return tuple([1 for _ in range(16)]), True

        return None, False


class Snake2DModel(Module):
    def __init__(self):
        super(Snake2DModel, self).__init__()
        self.conv1 = Conv2d(in_channels = 1, out_channels = 16, kernel_size = 5)
        self.conv2 = Conv2d(in_channels = 16, out_channels = 32, kernel_size = 3)
        self.fc1 = Linear(32 * 4 * 4, 256)
        self.fc2 = Linear(256, 4)
        torch.nn.init.kaiming_uniform_(self.conv1.weight)
        torch.nn.init.kaiming_uniform_(self.conv2.weight)
        torch.nn.init.kaiming_uniform_(self.fc1.weight)
        torch.nn.init.kaiming_uniform_(self.fc2.weight)

    def forward(self, x):
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = torch.flatten(x, 1)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x


class Snake2D(Snake):
    
    @property
    def state(self):
        state = np.zeros((self.num_columns, self.num_rows))
        state[self.apple.x][self.apple.y] = -1
        for i, j in self.body:
            state[i][j] = 1
        state[self.head.x][self.head.y] = 2
        return np.expand_dims(state, axis=0)


class Snake2DFramestackModel(Module):
    def __init__(self):
        super(Snake2DFramestackModel, self).__init__()
        self.conv1 = Conv2d(in_channels = 4, out_channels = 16, kernel_size = 5)
        self.conv2 = Conv2d(in_channels = 16, out_channels = 32, kernel_size = 3)
        self.fc1 = Linear(32 * 4 * 4, 256)
        self.fc2 = Linear(256, 4)
        torch.nn.init.kaiming_uniform_(self.conv1.weight)
        torch.nn.init.kaiming_uniform_(self.conv2.weight)
        torch.nn.init.kaiming_uniform_(self.fc1.weight)
        torch.nn.init.kaiming_uniform_(self.fc2.weight)

    def forward(self, x):
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = torch.flatten(x, 1)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x


class Snake2DFramestack(Snake):
    
    @property
    def state(self):
        state = np.zeros((self.num_columns, self.num_rows))
        state[self.apple.x][self.apple.y] = -1
        for i, j in self.body:
            state[i][j] = 1
        return state


if __name__ == "__main__":
    env = SnakeSimple(
        num_columns = 10,
        num_rows = 10,
        seed = 123
        )
    agent = Q_Agent(
        environment=env,
        learning_rate=0.1,
        discount_factor=0.9,
        epsilon_schedule = lambda n: linear_decay_schedule(
            n = n,
            base = 1,
            rate = 1e-4,
            min_val = 1e-3
            )
        )
    agent.play(
        filepath = 'models/snake_simple_q_table_linear_decay.pkl',
        num_episodes = 1
        )
    agent = Vanilla_DQN_Agent(
        environment = env,
        model_class = SnakeSimpleModel,
        learning_rate = 0.001,
        discount_factor = 0.9,
        epsilon_schedule = lambda n: linear_decay_schedule(
            n = n,
            base = 1,
            rate = 1e-4,
            min_val = 1e-3
            ),
        replay_buffer_size = 10,
        minimum_buffer_size = 10,
        batch_size = 32,
        weight_decay = 1e-2,
        update_frequency = 4,
        device = torch.device('cpu'),
        seed = 123
        )
    agent.play(
        model_class = SnakeSimpleModel,
        filepath = 'models/snake_simple_vanilla_dqn_linear_decay.pth',
        num_episodes = 1
        )
    agent = Double_DQN_Priority_Agent(
        environment = env,
        model_class = SnakeSimpleModel,
        learning_rate = 0.001,
        discount_factor = 0.9,
        epsilon_schedule = lambda n: linear_decay_schedule(
            n = n,
            base = 1,
            rate = 1e-4,
            min_val = 1e-3
            ),
        beta_schedule = lambda n: linear_growth_schedule(
            n = n,
            base = 0.6,
            max_val = 1,
            rate = 2e-5
            ),
        replay_buffer_size = 10,
        minimum_buffer_size = 10,
        batch_size = 32,
        weight_decay = 1e-2,
        alpha = 0.7,
        update_frequency = 4,
        device = torch.device('cpu')
        )
    agent.play(
        model_class = SnakeSimpleModel,
        filepath = 'models/snake_simple_double_dqn_with_priority_linear_decay.pth',
        num_episodes = 1
        )

        
    env = Snake2D(
        num_columns = 10,
        num_rows = 10,
        low = -1,
        high = 2,
        state_shape = (1, 10, 10),
        seed=1242
        )
    agent = Vanilla_DQN_Agent(
        environment = env,
        model_class = Snake2DModel,
        learning_rate = 1e-3,
        discount_factor = 0.9,
        epsilon_schedule = lambda n: linear_decay_schedule(
            n = n,
            base = 1,
            rate = 5e-5,
            min_val = 1e-3
            ),
        replay_buffer_size = 10,
        minimum_buffer_size = 10,
        batch_size = 32,
        update_frequency = 4,
        device = torch.device('cpu')
        )
    agent.play(
        model_class = Snake2DModel,
        filepath = 'models/snake_2d_vanilla_dqn_linear_decay.pth',
        num_episodes = 1
        )
    agent = Double_DQN_Priority_Agent(
        environment = env,
        model_class = Snake2DModel,
        learning_rate = 1e-3,
        discount_factor = 0.9,
        epsilon_schedule = lambda n: linear_decay_schedule(
            n = n,
            base = 1,
            rate = 5e-5,
            min_val = 1e-3
            ),
        beta_schedule = lambda n: linear_growth_schedule(
            n = n,
            base = 0.5,
            max_val = 1,
            rate = 1e-5
            ),
        replay_buffer_size = 10,
        minimum_buffer_size = 10,
        batch_size = 32,
        weight_decay = 1e-2,
        alpha=0.7,
        update_frequency = 4,
        device = torch.device('cpu'),
        seed=1242
        )
    agent.play(
        model_class = Snake2DModel,
        filepath = 'models/snake_2d_double_dqn_with_priority_linear_decay.pth',
        num_episodes = 1
        )
    
    
    env = Snake2DFramestack(
        num_columns = 10,
        num_rows = 10,
        low = -1,
        high = 1,
        state_shape = (10, 10)
        )
    env = FrameStack(env, 4)
    agent = Double_DQN_Priority_Agent(
        environment = env,
        model_class = Snake2DFramestackModel,
        learning_rate = 1e-3,
        discount_factor = 0.9,
        epsilon_schedule = lambda n: linear_decay_schedule(
            n = n,
            base = 1,
            rate = 5e-5,
            min_val = 1e-3
            ),
        beta_schedule = lambda n: linear_growth_schedule(
            n = n,
            base = 0.5,
            max_val = 1,
            rate = 1e-5
            ),
        replay_buffer_size = 10,
        minimum_buffer_size = 10,
        batch_size = 32,
        weight_decay = 1e-2,
        alpha=0.7,
        update_frequency = 4,
        device = torch.device('cpu')
        )
    agent.play(
        model_class = Snake2DFramestackModel,
        filepath = 'models/snake_2d_framestack_double_dqn_with_priority_linear_decay.pth',
        num_episodes = 1
        )